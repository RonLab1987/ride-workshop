<header id="page-top">
        <div class="container">
            <div class="intro-text">
                
                <div class="intro-heading">вы катаетесь</div>
                <div class="intro-lead-in">МЫ ОБСЛУЖИВАЕМ  </div>
                <!--div class="intro-lead-in">мы осблуживаем велосипед </div-->
                
                
                <a href="#services" class="page-scroll btn btn-xl btn-uci-blue">ПОДРОБНЕЕ</a>
                   <a href="#contact-form" class="page-scroll btn btn-xl btn-uci-green ">до нас 1 КЛИК <span class="glyphicon glyphicon-chevron-right "></span></a>
                <!--a href="#contact-form" class="page-scroll btn btn-xl btn-uci-green ">ДО МАСТЕРСКОЙ 1 КЛИК <span class="glyphicon glyphicon-chevron-right "></span></a-->
            </div>
        </div>
</header>