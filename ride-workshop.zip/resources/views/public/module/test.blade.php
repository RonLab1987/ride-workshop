<div class="jumbotron">
    <div class="container text-center">
        <h2>Web-приложение "КАТАЙ"</h2>
        <p>Framework's: Laravel, Bootstrap, jQuery(or AngularJS)</p>
        <p>Branch: RomanLaptev</p>
        <p>старт: 20.12.2015</p>
    </div>
</div>



