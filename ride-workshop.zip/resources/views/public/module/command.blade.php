
<section id="command">
    <div class="row">
        <div class="container">
            <h2 class="section-heading text-center">КОМАНДА</h2>
            <h3 class="section-subheading text-center text-muted">Давайте знакомиться</h3>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">

                    <div class="row">
                        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-6 col-xs-offset-3">
                         <img src="/image/leha1.jpg" class="img-responsive img-circle">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                        <h2 class="text-center">Алексей</h2>
                        <h5 class='text-center'> веломеханик, велосипедист, инженер</h5>
                        <div class="collapse col-sm-12" id='command-about-1'>
                            <p class="text-muted">Самым главным увлечением своей жизни считаю конструирование и проектирование,  решение различных технологических задач.</p>
                            <p class="text-muted">Катаю практически без перерывов с самого малого возраста благодаря бате, который и привил любовь к великам.</p>
                            <p class="text-muted">Велосипед — лучшее средство для поддержания себя в форме, как физической, так и душевной.</p>
                        </div>
                        <p class="text-center text-uppercase">
                            <a data-toggle='collapse' href="#command-about-1" aria-expanded='false' aria-controls='command-about-1'>подробнее <br>                            
                            <span class="glyphicon glyphicon-menu-down"></span>
                            </a> 
                        </p>
                        </div>
                    </div>

                </div>

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">

                    <div class="row">
                        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-6 col-xs-offset-3">
                         <img src="/image/i2.jpg" class="img-responsive img-circle">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                        <h2 class="text-center">Роман</h2>
                        <h5 class='text-center'>веломеханик, велосипедист, программист </h5>
                        <div class="collapse col-sm-12" id='command-about-2'>
                            <p class="text-muted">Люблю и уважаю велоспорт во всех его проявлениях. Так-же тяготею к триатлону — это плюс бег, плавание, лыжи.</p>
                            <p class="text-muted">Сам на велосипеде уже более 10 лет. Обслуживанием велосипедов занимаюсь более 3-х лет.</p>
                            <p class="text-muted">Всегда ценил удобный клиентский сервис и хорошо сделанную работу. Эти 2 принципа и стали основой нашей веломастерской  .</p>
                        </div>
                        <p class="text-center text-uppercase">
                            <a data-toggle='collapse' href="#command-about-2" aria-expanded='false' aria-controls='command-about-2'>подробнее <br>                            
                            <span class="glyphicon glyphicon-menu-down"></span>
                            </a> 
                        </p>
                        </div>
                    </div>

                </div>
            </div>
            <div class="row">
                
            </div>
        </div>
    </div>
    
</section>

