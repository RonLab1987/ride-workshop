

<section id="contact-data" class="bg-light-gray">
    <div class="container">    
        <h2 class="section-heading text-center text-uci-black">контакты</h2>
        <h3 class="section-subheading text-center">всегда на связи. </h3>
        <div class="row">
            
            
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right ">
                  <p class="">ЗВОНИТЕ</p>
                  <p class="text-muted"> Каждый день с 10 до 21.</p>
                  <p class="lead"><span class="glyphicon glyphicon-phone text-uci-green"></span> 43-45-95</p>
                  
                  <p class="">ПИШИТЕ</p>
                  <p class="text-muted">В любое время</p>
                  <p class=""><a href="#contact-form" class="page-scroll"><span class="glyphicon glyphicon-plane text-uci-green"></span> на сайте</a></p>
                  <p class=""><a href="https://vk.com/ron_vk" target="_blank"><span class="glyphicon glyphicon-share "></span> ВКонтакте</a></p>
                  
                  <p class="">ПРИВОЗИТЕ</p>
                  <p class="text-muted">
                    Необходимо договориться о времени.<br>
                    <a href="#contact-form" class="page-scroll">Оформите заявку на сайте </a> или по телефону.
                  </p>
                  <p class=""> <span class="glyphicon glyphicon-map-marker text-uci-green"></span> Киров, ул. Космонавта Волкова, д. 12</p>
                  <p class=""> <span class="glyphicon glyphicon-map-marker text-uci-blue"></span> Киров, ул. Ломоносова, д. 29</p>
                  <hr class="visible-xs">
            </div>
            
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
               <script type="text/javascript" charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=bJ8B3pj7AvYLkKM3KC-TL7rmYA61rcqQ&width=100%&height=400&lang=ru_RU&sourceType=constructor"></script>
               <hr class="visible-xs">
            </div>
            
            
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-left">
                <script type="text/javascript" src="//vk.com/js/api/openapi.js?121"></script>

                <!-- VK Widget -->
                <div id="vk_groups"></div>
                <script type="text/javascript">
                VK.Widgets.Group("vk_groups", {mode: 0, width: "auto", height: "400", color1: 'FFFFFF', color2: '2B587A', color3: '5B7FA6'}, 86529149);
                </script>
                <hr class="visible-xs">
            </div> 
                  
          </div>
         
    
        <div class="row">
            
        </div>
    </div>
    
</section>



