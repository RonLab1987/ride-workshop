<div  class="price-head" id="page-top">
        <div class="container">
            <div class="intro-text">
                
                <div class="intro-heading">доставка</div>
                <div class="intro-lead-in text-uppercase"> от 100 до 0 руб.<!--span class="glyphicon glyphicon-rub "></span--></div>
                <!--div class="intro-lead-in">мы осблуживаем велосипед </div-->
                
                <a href="#price-list" class="page-scroll btn btn-xl btn-uci-blue">ПОДРОБНЕЕ</a>
                <a href="{!! route('homepage') !!}#contact-form" class=" btn btn-xl btn-uci-green ">Всего 1 клик <span class="glyphicon glyphicon-chevron-right "></span></a>
            </div>
        </div>
</div>