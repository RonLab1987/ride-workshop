<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script-->
    <script src="/jquery/dist/jquery.min.js"></script>
    <script src="/jquery/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
    
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/bootstrap/dist/js/bootstrap.min.js"></script>
    <!--script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script-->
    
    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="/agency/js/classie.js"></script>
    <script src="/agency/js/cbpAnimatedHeader.js"></script>
    
    
    <!-- Custom Theme JavaScript -->
    <script src="/agency/js/agency.js"></script>
    <script src="/agency/js/contact-form-controll.js"></script>

